RaidNight Overlay for Overwolf
===============================

Nickname: Docjekyll
Real name: Chris Johnson
Email: jhnsn.c@gmail.com
Version: 1.0.0
Category: Social
Tags: raid, mmorpg, mmo, teamspeak, group, organization, team, guild, chat, clipboard, utility


Description
===========

It's Raid Night!
----------------
Make it go more smoothly with the "RaidNight" overlay for Overwolf.

Connect to TeamSpeak and put character names to chat voices. You can change a player's display name, icon, color, and group role. That way you know who to "HJEAL!" when you hear a voice in the middle of the boss fight.

RaidNight also makes it easier for you to lead your guild runs. Write and save your own "raid scripts" so you have easy access to links, text snippets, and reminders during the raid. This is great for keeping track of puzzle solvers, loot guides, wiki articles, or just saving yourself from typing the same instructions to puggers every run.

You can post info straight to your TeamSpeak channel with a single click or copy/paste into game chat so you spend less time typing and more time looting!

(Future updates will allow you to easily split your raid into smaller groups and copy/paste the group split into game chat. You will also be able to control more app settings.)
